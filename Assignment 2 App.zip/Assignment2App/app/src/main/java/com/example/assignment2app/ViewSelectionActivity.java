package com.example.assignment2app;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.io.File;

public class ViewSelectionActivity extends AppCompatActivity {
    private String imagePath;
    private String reader;
    private String result;
    private String id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_view_selection);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        ImageView imageView = findViewById(R.id.itemImageView);
        TextView titleView = findViewById(R.id.itemViewTitle);
        TextView outputView = findViewById(R.id.itemViewOutput);

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            id = extras.getString("id");

            imagePath = extras.getString("image");
            Bitmap bitmap = BitmapFactory.decodeFile(imagePath);
            imageView.setImageBitmap(bitmap);

            reader = extras.getString("title");
            titleView.setText(reader);

            result = extras.getString("output");
            outputView.setText(result);
        }
    }

    public void returnToListView(View view) {
        Intent intent = new Intent(ViewSelectionActivity.this, ListViewActivity.class);
        startActivity(intent);
    }

    public void editItem(View view) {
        Intent intent = new Intent(ViewSelectionActivity.this, EditActivity.class);
        intent.putExtra("image", imagePath);
        intent.putExtra("title", reader);
        intent.putExtra("output", result);
        intent.putExtra("id", id);
        startActivity(intent);
    }

    public void deleteItem(View view) {
        DatabaseReference dbref = FirebaseDatabase.getInstance().getReference("storage");
        dbref.child(id).removeValue();

        if (imagePath != null) {
            File file = new File(imagePath);

            if (file.exists()) {
                file.delete();
            }
        }
        // Open list view activity
        Intent intent = new Intent(ViewSelectionActivity.this, ListViewActivity.class);
        startActivity(intent);
    }
}