package com.example.assignment2app;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;

import java.util.ArrayList;

public class ItemAdapter extends ArrayAdapter<MLKitResult> {
    public ItemAdapter(Context context, ArrayList<MLKitResult> items) {
        super(context, 0, items);
    }

    @NonNull
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.list_item, parent, false);
        }

        // Alternate colors
        if (position % 2 == 0) {
            convertView.setBackgroundColor(Color.parseColor("#d4d4d4"));
        } else {
            convertView.setBackgroundColor(Color.parseColor("#FFFFFF"));
        }

        MLKitResult item = getItem(position);

        ImageView image = convertView.findViewById(R.id.listItemImageView);
        TextView label = convertView.findViewById(R.id.listItemTextView);

        label.setText(item.reader);
        Bitmap bitmap = BitmapFactory.decodeFile(item.imagePath);
        image.setImageBitmap(bitmap);

        return convertView;
    }
}
