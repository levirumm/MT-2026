package com.example.assignment2app;

public class MLKitResult {
    public String reader;
    public String result;
    public String imagePath;
    public String id;

    public MLKitResult(String reader, String result, String imagePath, String id) {
        this.reader = reader;
        this.result = result;
        this.imagePath = imagePath;
        this.id = id;
    }
}
