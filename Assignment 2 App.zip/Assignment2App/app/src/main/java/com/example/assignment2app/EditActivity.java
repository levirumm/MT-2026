package com.example.assignment2app;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.ImageDecoder;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

public class EditActivity extends AppCompatActivity {
    private Uri imageFileUri;
    private String id;
    private EditText editTextTitle;
    private EditText editTextOutput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_edit);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        ImageView imageView = findViewById(R.id.imageView2);
        editTextTitle = findViewById(R.id.textEditTitle);
        editTextOutput = findViewById(R.id.textEditOutput);

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            imageFileUri = Uri.parse(extras.getString("image"));
            imageView.setImageURI(imageFileUri);

            String title = extras.getString("title");
            editTextTitle.setText(title);

            String output = extras.getString("output");
            editTextOutput.setText(output);

            id = extras.getString("id");
        }
    }

    public void saveToDatabase(View view) {
        String filename;
        String path;

        DatabaseReference dbref = FirebaseDatabase.getInstance().getReference("storage");

        if (id.isEmpty()) {
            Bitmap bitmap = getBitmapFromUri(imageFileUri);

            if (bitmap == null) {
                Toast.makeText(this, "Failed to save image", Toast.LENGTH_SHORT).show();
                return;
            }

            filename = String.valueOf(System.currentTimeMillis());
            path = saveImageToInternal(bitmap, filename);
            dbref.child(filename).child("filename").setValue(path);

            if (path == null) {
                Toast.makeText(this, "Failed to save image", Toast.LENGTH_SHORT).show();
                return;
            }
        } else {
            filename = id;
        }
        dbref.child(filename).child("reader").setValue(editTextTitle.getText().toString());
        dbref.child(filename).child("result").setValue(editTextOutput.getText().toString());

        // Open list view activity
        Intent intent = new Intent(EditActivity.this, ListViewActivity.class);
        startActivity(intent);
    }

    private Bitmap getBitmapFromUri(Uri uri) {
        try {
            ImageDecoder.Source source = ImageDecoder.createSource(getContentResolver(), uri);
            return ImageDecoder.decodeBitmap(source);
        } catch (IOException e) {
            Log.e("URI_TO_BITMAP", "Failed to load image", e);
            return null;
        }
    }

    private String saveImageToInternal(Bitmap bitmap, String fileName) {
        File file = new File(getFilesDir(), fileName + ".jpg");
        try {
            FileOutputStream outputStream = new FileOutputStream(file);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 90, outputStream);
            outputStream.flush();
            outputStream.close();
            return file.getAbsolutePath();
        } catch (IOException e) {
            return null;
        }
    }
}