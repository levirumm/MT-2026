package com.example.assignment2app;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        ImageView barcodeImage = findViewById(R.id.imageViewBarcode);
        barcodeImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                onImageClick("barcode");
            }
        });

        ImageView contentImage = findViewById(R.id.imageViewContent);
        contentImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                onImageClick("content");
            }
        });

        ImageView textImage = findViewById(R.id.imageViewText);
        textImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                onImageClick("text");
            }
        });
    }

    public void onImageClick(String reader) {
        Intent intent = new Intent(MainActivity.this, MLKitActivity.class);
        intent.putExtra("reader", reader);
        startActivity(intent);
    }

    public void openAnalysedImages(View view) {
        Intent intent = new Intent(MainActivity.this, ListViewActivity.class);
        startActivity(intent);
    }
}